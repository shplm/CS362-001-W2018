# CS362-001-W2018
The Calendar is a Java application that provides classes and methods for storing diffirent appointments.
